const API_BASE = "api/";

let usuarioActual = JSON.parse(localStorage.getItem("usuarioActual")) || null;
let profesionalesCache = [];

/* =========================
   UTILIDADES API
========================= */
async function apiRequest(endpoint, options = {}) {
    const response = await fetch(API_BASE + endpoint, {
        headers: {
            "Content-Type": "application/json"
        },
        ...options
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.mensaje || "Error en la petición");
    }

    return data;
}

function escapeHtml(texto) {
    if (texto === null || texto === undefined) return "";
    return String(texto)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function obtenerPrimerNombre(nombreCompleto) {
    if (!nombreCompleto) return "Usuario";
    return nombreCompleto.trim().split(" ")[0];
}

function normalizarProfesional(pro) {
    return {
        id: Number(pro.id),
        nombre: pro.nombre || "Profesional",
        profesion: pro.profesion || pro.categoria_nombre || pro.especialidad || "Profesional del hogar",
        categoria: pro.categoria || "",
        rating: Number(pro.rating ?? pro.puntuacion_media ?? 0),
        reviews: Number(pro.reviews ?? pro.total_valoraciones ?? 0),
        ubicacion: pro.ubicacion || pro.ciudad || "Sin ubicación",
        img: pro.img || pro.imagen || "https://via.placeholder.com/400x300?text=BYH",
        verificado:
            pro.verificado === true ||
            pro.verificado === 1 ||
            pro.estado_validacion === "validado"
    };
}

/* =========================
   NAVBAR
========================= */
function actualizarNavbarUsuario() {
    const zone = document.getElementById("user-zone");
    if (!zone) return;

    if (usuarioActual) {
        zone.innerHTML = `
            <div class="d-flex align-items-center gap-2">
                <i class="bi bi-person-circle fs-4"></i>
                <strong>${escapeHtml(obtenerPrimerNombre(usuarioActual.nombre))}</strong>
            </div>
            <button onclick="cerrarSesion()" class="btn btn-outline-danger btn-sm">Salir</button>
        `;
    } else {
        zone.innerHTML = `<a href="registro.html" class="btn btn-outline-light">Iniciar sesión</a>`;
    }
}

function cerrarSesion() {
    localStorage.removeItem("usuarioActual");
    usuarioActual = null;
    window.location.href = "index.html";
}

/* =========================
   TARJETAS
========================= */
function crearTarjeta(profesional) {
    const pro = normalizarProfesional(profesional);

    return `
        <div class="col">
            <div class="pro-card position-relative">
                ${pro.verificado ? `<span class="pro-badge">✓ Verificado</span>` : ""}
                <img src="${escapeHtml(pro.img)}" alt="${escapeHtml(pro.nombre)}">
                <div class="p-3">
                    <h5>${escapeHtml(pro.nombre)}</h5>
                    <p class="text-success mb-2">${escapeHtml(pro.profesion)}</p>

                    <div class="d-flex align-items-center gap-1 mb-2">
                        <span class="text-warning">★ ${pro.rating > 0 ? pro.rating.toFixed(1) : "Nuevo"}</span>
                        <small class="text-white-50">${pro.reviews > 0 ? `(${pro.reviews})` : "(Sin reseñas)"}</small>
                    </div>

                    <small class="text-white-50">
                        <i class="bi bi-geo-alt"></i> ${escapeHtml(pro.ubicacion)}
                    </small>

                    <button onclick="verPerfil(${pro.id})" class="btn btn-success w-100 mt-3">
                        Ver perfil
                    </button>
                </div>
            </div>
        </div>
    `;
}

/* =========================
   INDEX
========================= */
async function renderizarProfesionales() {
    const container = document.getElementById("profesionales-container");
    if (!container) return;

    try {
        const data = await apiRequest("profesionales.php");
        profesionalesCache = Array.isArray(data) ? data : (data.profesionales || []);
        container.innerHTML = profesionalesCache.map(crearTarjeta).join("");
    } catch (error) {
        console.error(error);
        container.innerHTML = `
            <div class="col-12">
                <div class="alert alert-danger">
                    No se pudieron cargar los profesionales.
                </div>
            </div>
        `;
    }
}

function activarBuscador() {
    const searchInput = document.getElementById("search-input");
    const container = document.getElementById("profesionales-container");

    if (!searchInput || !container) return;

    searchInput.addEventListener("input", () => {
        const term = searchInput.value.trim().toLowerCase();

        const filtrados = profesionalesCache.filter((pro) => {
            const p = normalizarProfesional(pro);
            return (
                p.nombre.toLowerCase().includes(term) ||
                p.profesion.toLowerCase().includes(term) ||
                p.ubicacion.toLowerCase().includes(term)
            );
        });

        container.innerHTML = filtrados.map(crearTarjeta).join("");
    });
}

/* =========================
   CATEGORÍAS
========================= */
function obtenerCategoriaDesdeUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get("cat") || "todas";
}

async function filtrar(tipo = "puntuacion") {
    const cont = document.getElementById("lista-profesionales");
    const count = document.getElementById("count");
    if (!cont) return;

    const categoria = obtenerCategoriaDesdeUrl();

    try {
        const data = await apiRequest(`profesionales.php?cat=${encodeURIComponent(categoria)}&orden=${encodeURIComponent(tipo)}`);
        let lista = Array.isArray(data) ? data : (data.profesionales || []);

        lista = lista.map(normalizarProfesional);

        if (tipo === "puntuacion") {
            lista.sort((a, b) => b.rating - a.rating);
        }

        if (tipo === "cercania") {
            lista.sort((a, b) => a.ubicacion.localeCompare(b.ubicacion));
        }

        if (count) count.textContent = lista.length;
        cont.innerHTML = lista.map(crearTarjeta).join("");

        const btnPuntuacion = document.getElementById("btn-puntuacion");
        const btnCercania = document.getElementById("btn-cercania");

        if (btnPuntuacion) btnPuntuacion.classList.toggle("active", tipo === "puntuacion");
        if (btnCercania) btnCercania.classList.toggle("active", tipo === "cercania");
    } catch (error) {
        console.error(error);
        cont.innerHTML = `
            <div class="col-12">
                <div class="alert alert-danger">
                    No se pudieron cargar los profesionales de esta categoría.
                </div>
            </div>
        `;
    }
}

/* =========================
   PERFIL
========================= */
async function cargarPerfil() {
    if (!window.location.pathname.includes("perfil.html")) return;

    const params = new URLSearchParams(window.location.search);
    const id = parseInt(params.get("id"), 10);
    const cont = document.getElementById("perfil-container");

    if (!cont || !id) return;

    try {
        const data = await apiRequest(`perfil.php?id=${id}`);
        const pro = normalizarProfesional(data.profesional || data);

        cont.innerHTML = `
            <div class="row">
                <div class="col-md-5">
                    <img src="${escapeHtml(pro.img)}" class="img-fluid rounded shadow" alt="${escapeHtml(pro.nombre)}">
                </div>

                <div class="col-md-7">
                    <h1 class="fw-bold">${escapeHtml(pro.nombre)}</h1>
                    <h4 class="text-success">${escapeHtml(pro.profesion)}</h4>

                    <div class="d-flex align-items-center gap-2 my-3">
                        <span class="text-warning fs-4">★ ${pro.rating > 0 ? pro.rating.toFixed(1) : "Nuevo"}</span>
                        <span class="text-white-50">${pro.reviews > 0 ? `(${pro.reviews} reseñas)` : "(Sin reseñas)"}</span>
                    </div>

                    <p><i class="bi bi-geo-alt"></i> ${escapeHtml(pro.ubicacion)}</p>

                    <p class="mt-4">
                        ${escapeHtml(data.descripcion || "Profesional con experiencia en el sector, atención personalizada y trabajo de calidad.")}
                    </p>

                    <h5 class="mt-4">Servicios ofrecidos</h5>
                    <ul>
                        <li>Trabajo profesional y garantizado</li>
                        <li>Presupuesto sin compromiso</li>
                        <li>Atención rápida</li>
                    </ul>

                    <button onclick="contactar(${pro.id})" class="btn btn-success btn-lg mt-4">
                        Contactar ahora
                    </button>
                </div>
            </div>
        `;
    } catch (error) {
        console.error(error);
        cont.innerHTML = `
            <div class="alert alert-danger">
                No se pudo cargar el perfil del profesional.
            </div>
        `;
    }
}

function verPerfil(id) {
    window.location.href = `perfil.html?id=${id}`;
}

function contactar(id) {
    alert(`Contacto con el profesional ${id} en desarrollo.`);
}

/* =========================
   REGISTRO
========================= */
function selectType(type) {
    const selection = document.getElementById("selection-step");
    const formCliente = document.getElementById("form-cliente");
    const formProfesional = document.getElementById("form-profesional");

    if (selection) selection.classList.add("d-none");

    if (type === "cliente") {
        if (formCliente) formCliente.classList.remove("d-none");
        if (formProfesional) formProfesional.classList.add("d-none");
    } else {
        if (formProfesional) formProfesional.classList.remove("d-none");
        if (formCliente) formCliente.classList.add("d-none");
    }
}

async function handleRegister(e, tipo) {
    e.preventDefault();

    let payload = {
        rol: tipo
    };

    if (tipo === "cliente") {
        payload.nombre = document.getElementById("cliente-nombre").value.trim();
        payload.apellidos = document.getElementById("cliente-apellidos").value.trim();
        payload.email = document.getElementById("cliente-email").value.trim();
        payload.password = document.getElementById("cliente-pass").value;
    } else {
        payload.nombre = document.getElementById("pro-nombre").value.trim();
        payload.apellidos = "";
        payload.email = document.getElementById("pro-email").value.trim();
        payload.password = document.getElementById("pro-pass").value;
        payload.especialidad = document.getElementById("pro-especialidad").value.trim();
    }

    try {
        const data = await apiRequest("registro.php", {
            method: "POST",
            body: JSON.stringify(payload)
        });

        if (data.usuario) {
            usuarioActual = data.usuario;
            localStorage.setItem("usuarioActual", JSON.stringify(usuarioActual));
        }

        alert(data.mensaje || "Registro completado");
        window.location.href = "index.html";
    } catch (error) {
        console.error(error);
        alert(error.message || "No se pudo completar el registro");
    }
}

async function handleLogin(e) {
    e.preventDefault();

    const payload = {
        email: document.getElementById("login-email").value.trim(),
        password: document.getElementById("login-pass").value
    };

    try {
        const data = await apiRequest("login.php", {
            method: "POST",
            body: JSON.stringify(payload)
        });

        usuarioActual = data.usuario;
        localStorage.setItem("usuarioActual", JSON.stringify(usuarioActual));

        alert(data.mensaje || "Inicio de sesión correcto");
        window.location.href = "index.html";
    } catch (error) {
        console.error(error);
        alert(error.message || "Credenciales incorrectas");
    }
}

/* =========================
   UTILIDADES UI
========================= */
function togglePassword(id) {
    const input = document.getElementById(id);
    if (!input) return;

    input.type = input.type === "password" ? "text" : "password";
}

function switchTab(tab) {
    document.querySelectorAll(".nav-link").forEach((el, i) => {
        el.classList.toggle("active", i === tab);
    });

    const selection = document.getElementById("selection-step");
    const formCliente = document.getElementById("form-cliente");
    const formProfesional = document.getElementById("form-profesional");
    const formLogin = document.getElementById("form-login");

    if (selection) selection.classList.toggle("d-none", tab !== 0);
    if (formCliente) formCliente.classList.add("d-none");
    if (formProfesional) formProfesional.classList.add("d-none");
    if (formLogin) formLogin.classList.toggle("d-none", tab !== 1);
}

/* =========================
   INICIO
========================= */
document.addEventListener("DOMContentLoaded", () => {
    actualizarNavbarUsuario();
    renderizarProfesionales();
    activarBuscador();
    cargarPerfil();

    if (window.location.pathname.includes("categoria.html")) {
        filtrar("puntuacion");
    }
});