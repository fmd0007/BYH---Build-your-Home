<?php
declare(strict_types=1);

require_once 'conexion.php';

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode([
        'mensaje' => 'Datos no válidos'
    ]);
    exit;
}

$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';

if ($email === '' || $password === '') {
    http_response_code(400);
    echo json_encode([
        'mensaje' => 'Faltan credenciales'
    ]);
    exit;
}

$sql = "
    SELECT id, nombre, apellidos, email, password_hash, rol, estado_validacion, activo
    FROM usuarios
    WHERE email = :email
    LIMIT 1
";

$stmt = $conexion->prepare($sql);
$stmt->execute([':email' => $email]);
$usuario = $stmt->fetch();

if (!$usuario) {
    http_response_code(401);
    echo json_encode([
        'mensaje' => 'Correo o contraseña incorrectos'
    ]);
    exit;
}

if (!(bool)$usuario['activo']) {
    http_response_code(403);
    echo json_encode([
        'mensaje' => 'La cuenta está desactivada'
    ]);
    exit;
}

if (!password_verify($password, $usuario['password_hash'])) {
    http_response_code(401);
    echo json_encode([
        'mensaje' => 'Correo o contraseña incorrectos'
    ]);
    exit;
}

echo json_encode([
    'mensaje' => 'Inicio de sesión correcto',
    'usuario' => [
        'id' => (int)$usuario['id'],
        'nombre' => trim($usuario['nombre'] . ' ' . $usuario['apellidos']),
        'email' => $usuario['email'],
        'rol' => $usuario['rol'],
        'estado_validacion' => $usuario['estado_validacion']
    ]
], JSON_UNESCAPED_UNICODE);