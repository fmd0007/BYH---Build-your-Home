<?php
declare(strict_types=1);

require_once 'conexion.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    http_response_code(400);
    echo json_encode([
        'mensaje' => 'ID no válido'
    ]);
    exit;
}

$sql = "
    SELECT 
        u.id,
        u.nombre,
        u.apellidos,
        u.ciudad,
        u.telefono,
        u.direccion,
        u.estado_validacion,
        c.nombre AS categoria_nombre,
        c.descripcion AS categoria_descripcion
    FROM usuarios u
    LEFT JOIN profesional_categorias pc ON u.id = pc.profesional_id
    LEFT JOIN categorias c ON pc.categoria_id = c.id
    WHERE u.id = :id AND u.rol = 'profesional'
    LIMIT 1
";

$stmt = $conexion->prepare($sql);
$stmt->execute([':id' => $id]);
$fila = $stmt->fetch();

if (!$fila) {
    http_response_code(404);
    echo json_encode([
        'mensaje' => 'Profesional no encontrado'
    ]);
    exit;
}

$nombreCompleto = trim($fila['nombre'] . ' ' . $fila['apellidos']);

$profesional = [
    'id' => (int)$fila['id'],
    'nombre' => $nombreCompleto,
    'profesion' => $fila['categoria_nombre'] ?? 'Profesional del hogar',
    'rating' => 4.8,
    'reviews' => 12,
    'ubicacion' => $fila['ciudad'] ?? 'Sin ubicación',
    'img' => 'https://via.placeholder.com/400x300?text=BYH',
    'verificado' => $fila['estado_validacion'] === 'validado'
];

echo json_encode([
    'profesional' => $profesional,
    'descripcion' => $fila['categoria_descripcion'] ?? 'Profesional con experiencia en el sector.'
], JSON_UNESCAPED_UNICODE);