<?php
declare(strict_types=1);

require_once 'conexion.php';

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode([
        'mensaje' => 'Datos no válidos'
    ]);
    exit;
}

$nombre = trim($input['nombre'] ?? '');
$apellidos = trim($input['apellidos'] ?? '');
$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';
$rol = $input['rol'] ?? 'cliente';
$especialidad = trim($input['especialidad'] ?? '');

if ($nombre === '' || $email === '' || $password === '') {
    http_response_code(400);
    echo json_encode([
        'mensaje' => 'Faltan campos obligatorios'
    ]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode([
        'mensaje' => 'Correo electrónico no válido'
    ]);
    exit;
}

if (!in_array($rol, ['cliente', 'profesional'], true)) {
    http_response_code(400);
    echo json_encode([
        'mensaje' => 'Rol no válido'
    ]);
    exit;
}

$check = $conexion->prepare("SELECT id FROM usuarios WHERE email = :email LIMIT 1");
$check->execute([':email' => $email]);

if ($check->fetch()) {
    http_response_code(409);
    echo json_encode([
        'mensaje' => 'Ese correo ya está registrado'
    ]);
    exit;
}

$passwordHash = password_hash($password, PASSWORD_DEFAULT);
$estadoValidacion = $rol === 'profesional' ? 'pendiente' : 'validado';

$sql = "
    INSERT INTO usuarios (
        nombre, apellidos, email, password_hash, telefono, direccion, ciudad, rol, estado_validacion, activo
    ) VALUES (
        :nombre, :apellidos, :email, :password_hash, NULL, NULL, NULL, :rol, :estado_validacion, 1
    )
";

$stmt = $conexion->prepare($sql);
$stmt->execute([
    ':nombre' => $nombre,
    ':apellidos' => $apellidos,
    ':email' => $email,
    ':password_hash' => $passwordHash,
    ':rol' => $rol,
    ':estado_validacion' => $estadoValidacion
]);

$usuarioId = (int)$conexion->lastInsertId();

if ($rol === 'profesional' && $especialidad !== '') {
    $buscarCategoria = $conexion->prepare("SELECT id FROM categorias WHERE nombre = :nombre LIMIT 1");
    $buscarCategoria->execute([':nombre' => $especialidad]);
    $categoria = $buscarCategoria->fetch();

    if ($categoria) {
        $insertRelacion = $conexion->prepare("
            INSERT INTO profesional_categorias (profesional_id, categoria_id)
            VALUES (:profesional_id, :categoria_id)
        ");
        $insertRelacion->execute([
            ':profesional_id' => $usuarioId,
            ':categoria_id' => $categoria['id']
        ]);
    }
}

echo json_encode([
    'mensaje' => 'Usuario registrado correctamente',
    'usuario' => [
        'id' => $usuarioId,
        'nombre' => trim($nombre . ' ' . $apellidos),
        'email' => $email,
        'rol' => $rol
    ]
], JSON_UNESCAPED_UNICODE);